//
//  EPGHeaderCell.swift
//  EPG
//
//  Created by Shabeerali Kudukkil on 30/01/19.
//  Copyright © 2019 CX. All rights reserved.
//

import UIKit

class EPGHeaderCell: UICollectionViewCell {
    @IBOutlet weak var programTIme: UILabel!
}
