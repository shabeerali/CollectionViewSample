//
//  EPGCollectionViewCell.swift
//  EPG
//
//  Created by Adnan Aftab on 2/14/15.
//  Copyright (c) 2015 CX. All rights reserved.
//

import UIKit

class EPGCollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var programName: UILabel!
    @IBOutlet weak var programTIme: UILabel!
}
