//
//  MetaAbstractClass.swift
//  ObjCToSwiftMigration
//
//  Created by Shabeerali Kudukkil on 24/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation


let VSP_SELF_DEFINE_ELEMENT = "urlSuffixParameters"
let VSP_PACKAGE_MAXLENGTH = 1073741824
private var gDynClassDic: [AnyHashable : Any]? = nil

class MetaAbstractClass:NSObject, OTTPackageProtocol {
    func unpack(_ source: Data?) -> Any? {
        <#code#>
    }
    
    func classforJsonName(jsonName: String?) -> AnyClass {
        <#code#>
    }
    
    func valueforKey(key: String) -> Any? {
        <#code#>
    }
    

    func valueforUndefinedKey (key: String) -> Any? {
       // DS_ERROR("[%@] don't exist the [%@]", NSStringFromClass(type(of: self).self), key)
    
    return nil
    }
    
    func spacialCaseMatchingTableForString() -> [String : Any]? {
        return [
            "mID": "id",
            "mDescription": "description",
            "mTemplate": "template",
            "mNewPwd": "newPwd",
            "mNewScores": "newScores"
        ]
    }
    
    // MARK: - MetaObject -> JSON
    func pack() -> Data? {
        let aDic = classToDictionary()
        if JSONSerialization.isValidJSONObject(aDic as Any) {
            //var error: Error?
            let jsonData: Data? = try? JSONSerialization.data(withJSONObject: aDic as Any, options: .prettyPrinted)
            return jsonData
        }
        return nil
    }

    func classToDictionary() -> [String : Any]? {
        var aDic: [String:Any] = [:]
        aDic["Name"] = "shabeer"
        weak var weakSelf: MetaAbstractClass? = self
        iterateProperties(usingBlock: { propertyName, propertyInfo in
            //DS_DEBUG(@"iteratePropertiesUsingBlock:propertyName=%@ ", propertyName);
            let propertyValue = self.valueforKey(key:propertyName!)
            if nil == propertyValue {
                return
            }
            if (propertyName == VSP_SELF_DEFINE_ELEMENT) {
                return
            }
            
            var elementName = self.spacialCaseMatchingTableForString()?[propertyName!] ?? propertyName!
            if (propertyValue is String) {
                if let propertyValue = propertyValue {
                    aDic[elementName] = propertyValue
                }
            } else if (propertyValue is MetaAbstractClass) {
                let metaValue = propertyValue?.classToDictionary()
                if metaValue != nil {
                    if let metaValue = metaValue {
                        aDic[elementName] = metaValue
                    }
                }
            } else if (propertyValue is [Any]) {
                aDic[elementName] = self.pack(inArray: propertyValue)
            } else if (propertyValue is [AnyHashable : Any]) {
                aDic[elementName] = self.pack(inDictionary: propertyValue)
            }
        })
        return aDic
    
}
