//
//  NSObject+PropertyIteration.swift
//  ObjCToSwiftMigration
//
//  Created by Shabeerali Kudukkil on 24/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation
import libkern
import ObjectiveC
import os
private var sharedAttributesCache: [String : Any]? = nil
private var sharedLock =  os_unfair_lock()


typealias PropertyHandler = (String?, PropertyInfo?) -> Void

extension NSObject {
    
    class func load() {
        // TODO: [Swiftify] ensure that the code below is executed only once (`dispatch_once()` is deprecated)
        do {
            sharedAttributesCache = [String : Any]()
        }
    }
    func iterateProperties(usingBlock handler: PropertyHandler) {
        iteratePropertiesOf(NSObject.self, usingBlock: handler, stopped: NSObject.self)
    }
    func iteratePropertiesOf(_ aClass: AnyClass, usingBlock handler: PropertyHandler, stopped cls: AnyClass) {
        autoreleasepool {
            os_unfair_lock_lock(&sharedLock)
            var attributes = sharedAttributesCache
            
            os_unfair_lock_lock(&sharedLock)
            
            #if false
            if !attributes {
                attributes = [String : Any]?
    
                var aCls: AnyClass = type(of: self)
                while cls != aCls {
                    iterateIvarsOf(aCls, inDictionary: attributes)
                    aCls = class_getSuperclass(aCls)
                }
                
                os_unfair_lock_lock(&sharedLock)
                sharedAttributesCache[NSStringFromClass(aClass.self)] = attributes
                os_unfair_lock_lock(&sharedLock)
            }
            #endif
            
            
            for propertyName: String? in (attributes?.keys)! {
                handler(propertyName, attributes![propertyName!] as? PropertyInfo)
            }
        }
    }
    
    func iterateIvarsOf(_ aClass: AnyClass, inDictionary aDic: [AnyHashable : Any]?) {
        var aDic = aDic
        var count: UInt = 0
        
        let ivarList: Ivar? = class_copyIvarList(aClass, &count)
        
        for i in 0..<count {
            let ivar: Ivar? = ivarList?[i]
            // remove prefix "_"
            let ivarName = String(utf8String: ivar_getName(ivar) + 1)
            
            let encoding = ivar_getTypeEncoding(ivar)
            // filter basic types
            if !encoding || strlen(encoding) <= 3 {
                continue
            }
            let typeEncoding = String(utf8String: &encoding)
            
            // type encoding format:
            // T : @"NSObject"
            let ivarType = (typeEncoding as NSString?)?.substring(with: NSRange(location: 2, length: (typeEncoding?.count ?? 0) - 3))
            
            aDic?[ivarName ?? ""] = PropertyInfo(name: ivarName, type: ivarType)
        }
        
        free(ivarList)
    }

}




