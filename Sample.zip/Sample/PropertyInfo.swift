//
//  PropertyInfo.swift
//  ObjCToSwiftMigration
//
//  Created by Shabeerali Kudukkil on 24/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation

enum PropertyType : Int {
    case PTUnkown
    case PTString
    case PTMutableString
    case PTArray
    case PTMutableArray
    case PTDictionary
    case PTMutableDictionary
    case PTMetaClass
}

class PropertyInfo: NSObject {
    
    /**
     propertyType
     */
    var propertyType: PropertyType?
    /**
     name
     */
    var name :String?
    /**
     type
     */
    var type :String?
    
    convenience init(name: String?, type: String?) {
        let info = PropertyInfo()
        info.name = name
        info.type = type
        
        if type?.contains("NSString") ?? false {
            info.propertyType = PropertyType.PTString
        } else if type?.contains("NSMutableString") ?? false {
            info.propertyType = PropertyType.PTMutableString
        } else if type?.contains("NSArray") ?? false {
            info.propertyType = PropertyType.PTArray
        } else if type?.contains("NSMutableArray") ?? false {
            info.propertyType = PropertyType.PTMutableArray
        } else if type?.contains("NSDictionary") ?? false {
            info.propertyType = PropertyType.PTDictionary
        } else if type?.contains("NSMutableDictionary") ?? false {
            info.propertyType = PropertyType.PTMutableDictionary
        } else if type?.contains("Meta") ?? false {
            info.propertyType = PropertyType.PTMetaClass
        }
    }
}
