//
//  EPGChannelCollectionViewCell.swift
//  EPG
//
//  Created by Shabeerali Kudukkil on 31/01/19.
//  Copyright © 2019 CX. All rights reserved.
//

import UIKit

class EPGChannelCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
