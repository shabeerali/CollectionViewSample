//
//  EPGMainTimeCollectionHeaderViewCollectionReusableView.swift
//  EPG
//
//  Created by Shabeerali Kudukkil on 30/01/19.
//  Copyright © 2019 CX. All rights reserved.
//

import UIKit

class EPGMainTimeCollectionHeaderViewCollectionReusableView: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
