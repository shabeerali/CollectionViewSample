//
//  DateUtils.swift
//  RainbowSDK
//
//  Created by Basil Baby on 16/01/18.
//  Copyright © 2018 Infosys. All rights reserved.
//

import UIKit

class DateUtils: NSObject {
    
    
    //MARK :- HELPERS
    func secondsToTime (_ seconds: Double) -> (String) {
        let date = NSDate(timeIntervalSince1970: TimeInterval(seconds))
        let dateFormatter = DateFormatter()
        dateFormatter.timeStyle = DateFormatter.Style.short //Set time style
        dateFormatter.timeZone = TimeZone.current
        return dateFormatter.string(from: date as Date)
    }
    
    func secondsToDate (_ seconds: Double) -> (String) {
        let date = NSDate(timeIntervalSince1970: TimeInterval(seconds))
        let calendar = NSCalendar.current
        if calendar.isDateInYesterday(date as Date) { return "Yesterday" }
        else if calendar.isDateInToday(date as Date as Date) { return "Today" }
        else if calendar.isDateInTomorrow(date as Date) { return "Tomorrow" }
        else {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "EEE - MMM dd, yyyy"
            return dateFormatter.string(from: date as Date)
        }
    }
    func secondsToMinutes(_ seconds:Double) -> Int{
        let date = NSDate(timeIntervalSince1970: TimeInterval(seconds))
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: date as Date)
        let minute = calendar.component(.minute, from: date as Date)
        return (hour * 60 + minute)
    }
    func secondsToHoursMinutes (seconds : Double) -> (String) {
        let hour : Int = Int(seconds / 3600)
        let min : Int =  Int(seconds.truncatingRemainder(dividingBy:3600)) / 60
        var timeStr : String = ""
        if( hour >= 1) {
            timeStr = String(hour) + " hr "
        }
        if(min > 0){
            timeStr = timeStr + String(min) + " mins"
        }
        return timeStr
    }
    
    func currentDayString() -> String{
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = " MMM dd (EE)"
        return dateFormatter.string(from: date)
    }
    
    func timeFormat(_ time: Double) -> String {
        let dateFormatter = DateFormatter()
        let date = Date(timeIntervalSince1970: time)
        dateFormatter.dateFormat = "hh:mm:ss"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        return dateFormatter.string(from: date)
    }
    
    func getTheCurrentRoundTime() ->Int {
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: date)
        return hour
    }
    
    func getEPHOCTime(_ time : Double ) ->Int64 {
        let date = Date(timeIntervalSince1970: time)
        return Int64(date.timeIntervalSince1970 )
    }
    
    func getCurrentEPHOCTime() ->Int64 {
        let date = NSDate()
        return Int64(date.timeIntervalSince1970 )
    }
    func getTomorowEPHOCTime() ->Int64 {
        let today = Date()
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: today)
        return Int64(tomorrow!.timeIntervalSince1970 )
    }
    
    func thirtyMinTimeArray() -> [String] {
        let nearestTime = nearestThirtyMinutes()
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: nearestTime)
        let minute = calendar.component(.minute, from: nearestTime)
        let startTimeInSeconds =  (hour * 60 * 60) + (minute * 60)
        let endTimeInSeconds = startTimeInSeconds + (24 * 60 * 60)
        let time = Time(start: TimeInterval(startTimeInSeconds), interval: 30 * 60, end: TimeInterval(endTimeInSeconds))
        print(time.timeRepresentations)
        return time.timeRepresentations
    }
    
    func  extendMinTimeArray(_ timeArray: [String]) -> [String] {
        var newTimeArray = timeArray
        newTimeArray.append(contentsOf: timeArray)
        return newTimeArray
    }
    
    func nearestThirtyMinutes() -> Date {
        let date = Date()
        let calendar = Calendar.current
        let minutes = calendar.component(.minute, from: date)
        var newDate = Date()
        var val = 0
        if(minutes > 0 && minutes < 30) {
            newDate = calendar.date(byAdding:.minute, value: -minutes, to: date)!
            return newDate
        } else if(minutes > 30 && minutes < 60) {
            val = minutes - 30 ;
            newDate = calendar.date(byAdding:.minute, value: -val, to: date)!
            return newDate
        } else {
            return newDate
        }
    }
    
    func nextThirtyMinTimeArray(from time: Int64) -> [String] {
        let nearestTime = nearestThirtyMinutes(from: time)
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: nearestTime)
        let minute = calendar.component(.minute, from: nearestTime)
        let startTimeInSeconds =  (hour * 60 * 60) + (minute * 60)
        let endTimeInSeconds = startTimeInSeconds + (24 * 60 * 60)
        let time = Time(start: TimeInterval(startTimeInSeconds), interval: 30 * 60, end: TimeInterval(endTimeInSeconds))
        print(time.timeRepresentations)
        return time.timeRepresentations
    }
    
    func nearestThirtyMinutes(from time: Int64) -> Date {
        let date = Date(timeIntervalSince1970: TimeInterval(Double(time)))
        let calendar = Calendar.current
        let minutes = calendar.component(.minute, from: date)
        var newDate = Date()
        var val = 0
        if(minutes > 0 && minutes < 30) {
            newDate = calendar.date(byAdding:.minute, value: -minutes, to: date)!
            return newDate
        } else if(minutes > 30 && minutes < 60) {
            val = minutes - 30 ;
            newDate = calendar.date(byAdding:.minute, value: -val, to: date)!
            return newDate
        } else {
            return newDate
        }
    }
    
    func futureThirtyMinutes() -> Date {
        let date = Date()
        let calendar = Calendar.current
        let minutes = calendar.component(.minute, from: date)
        var newDate = Date()
        var val = 0
        if(minutes > 0 && minutes < 30) {
            newDate = calendar.date(byAdding:.minute, value: 30 - minutes, to: date)!
            return newDate
        } else if(minutes > 30 && minutes < 60) {
            val = 60 - minutes ;
            newDate = calendar.date(byAdding:.minute, value: val, to: date)!
            return newDate
        } else {
            return newDate
        }
    }
}

