//
//  LoginRouteReq.swift
//  GoldApp
//
//  Created by Shabeerali Kudukkil on 16/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation
class LoginRouteReq : SNetReq {
    
    
    /**
     subscriberID
     */
    var subscriberID : String?
    /**
     physicalDeviceID
     */
    var physicalDeviceID : String?
    /**
     deviceModel
     */
    var deviceModel : String?
    /**
     disableVSPAddr
     */
    var disableVSPAddr : String?
    /**
     reqURL
     
     @return NSString
     */
    override func reqURL() -> String? {
        
        //return UserInfoCS.loginUrl //@"http://10.10.10.232:8086/EDS/V3/LoginRoute";
         return "http://192.168.1.13:8080/EDS/V3/LoginRoute";
    }
    
    /**
     reqLevel
     
     @return OTTReqLevel
     */
    override func reqLevel() -> OTTReqLevel {
        return OTTReqLevel.ott_NORMAL_REQ
    }
    
    /**
     writeDownInLog
     
     @return BOOL
     */
    override func writeDownInLog() -> Bool {
        return true
        
    }
    
    /**
     httpShortLink
     
     @return BOOL
     */
    override func httpShortLink() -> Bool {
        return true
    }
}
