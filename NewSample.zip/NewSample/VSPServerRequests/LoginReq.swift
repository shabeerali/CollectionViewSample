//
//  LoginReq.swift
//  GoldApp
//
//  Created by Shabeerali Kudukkil on 17/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation
class LoginReq: SNetReq {
    /*!
     *    @brief  O    Subscriber ID for message tracking and VSP scheduling based on subscriber IP.
     */
    var subscriberID: String?
    /*!
     *    @brief  O    Terminal type
     */
    var deviceModel: String?
    
    override func reqURL() -> String? {
        return "\(UserInfoManager.shared().vspURL ?? "dss")\(VSP_NAMESPACE)\("Login")"
    }
    
    override func reqLevel() -> OTTReqLevel {
        return OTTReqLevel.ott_HIGHT_REQ
    }
    
    override func writeDownInLog() -> Bool {
        #if TARGET_IPHONE_SIMULATOR
        return true
        #else
        return false
        #endif
    }
}
