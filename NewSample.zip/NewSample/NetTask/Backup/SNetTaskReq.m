//
//  SNetTaskReq.m
//  OTTSDKTest
//
//  Created by OTT on 2017/11/7.
//  Copyright © 2017年 huawei. All rights reserved.
//

#import "SNetTaskReq.h"

@implementation SNetTaskReq

- (instancetype)initWithOTTReq:(OTTReqRef)ottReq
{
    if (self = [super init]) {
        self.ottReq = ottReq;
        self.httpReq.url = [ottReq reqURL];
        if ([ottReq httpPostMethod]) {
            self.httpReq.method = MSAHTTP_POST;
        }
        else {
            self.httpReq.method = MSAHTTP_GET;
        }
        
        if ([ottReq writeDownInLog]) {
            self.isPrintLog = YES;
        }
    }
    return self;
}

- (void)prepare
{
    self.httpReq.body = [self.ottReq pack];
}

- (MsaAccessResponse *)response
{
    SNetTaskRsp *aRsp = [[SNetTaskRsp alloc] init];
    aRsp.ottRsp = (OTTRspRef)[self.ottReq rspObject];
    return aRsp;
}

@end
