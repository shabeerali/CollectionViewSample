//
//  SNetTask.m
//  Megatron
//
//  Copyright (c) 2015年 huawei. All rights reserved.
//

#import "SNetTask.h"
#import "DSLog.h"
#import "MsaAccess.h"
#import "SNetTaskReq.h"
#import "SNetCatchEvent.h"

static BOOL gSNetTaskNormal = YES;
static RationalCheckRef gRationalCheck = nil;
static unsigned int gTimeout = 0;
static NSMutableArray<NSNumber *> *gErrorArray= nil;
static BOOL gDisableVerifyHttpsCert = NO;

@interface SNetTask ()

@property(nonatomic, strong) MsaAccess *access;

@end

@implementation SNetTask

- (id)init
{
    if (self = [super init]) {
        self.access = [[MsaAccess alloc] init];
    }
    return self;
}

- (BOOL)send:(OTTReqRef)aReq
     success:(void (^)(OTTReqRef aReq, OTTRspRef aRsp))success
     failure:(void (^)(OTTReqRef aReq, NSError *error))failure
{
    return [self send:aReq success:success failure:failure retryTimes:0];
}

- (BOOL)send:(OTTReqRef)aReq
     success:(void (^)(OTTReqRef aReq, OTTRspRef aRsp))success
     failure:(void (^)(OTTReqRef aReq, NSError *error))failure
  retryTimes:(NSInteger)rtimes
{
    NSAssert((aReq != nil && success != nil && failure != nil), @"SNetTask send not accept nil parameter");
    
    DS_DEBUG(@"SNetTask send \"%@\", level = %ld", NSStringFromClass([aReq class]), (long)(long)([aReq reqLevel]));
    if ( !gSNetTaskNormal ) {
        DS_DEBUG(@"SNetTask have benn called stopTask, need call resumeTask first, request will be discarded");
        NSError *error = [[NSError alloc] initWithDomain:@"SystemRestart" code:OTT_SYSTEM_CANCEL_REQUEST userInfo:nil];
        failure(aReq, error);
        return NO;
    }
    
    if ( gRationalCheck ) {
        if ( !gRationalCheck(aReq) ) {
            DS_ERROR(@"SNetTask rational check failed for %@", NSStringFromClass([aReq class]));
            NSError *error = [[NSError alloc] initWithDomain:@"SystemRestart" code:OTT_SYSTEM_LOGIN_OCCASION userInfo:nil];
            failure(aReq, error);
            return NO;
        }
    }
    
    SNetTaskReq *myReq = [[SNetTaskReq alloc] initWithOTTReq:aReq];
    myReq.isPrintLog = YES;
    myReq.successBlock = success;
    myReq.failureBlock = failure;
    
    if (gTimeout > 0) {
        myReq.httpReq.timeout = gTimeout;
    }
    
    if (rtimes > 0 && gErrorArray.count > 0) {
        myReq.httpReq.retryTimes = (unsigned int)rtimes;
        myReq.httpReq.retryExceptionCode = [NSMutableArray arrayWithArray:gErrorArray];
    }
    
    if (gDisableVerifyHttpsCert) {
        myReq.httpReq.verifyCertFlag = NO;
    }
    
    //__weak __typeof(self) weakSelf = self;
    [self.access send:myReq completion:^(MsaAccessRequest *aReq, MsaAccessResponse *aRsp) {
        SNetTaskReq *request = (SNetTaskReq *)aReq;
        SNetTaskRsp *response = (SNetTaskRsp *)aRsp;
        if ([aRsp success]) {
           // [SNETCEvent.unified successReceiveResponse:response.ottRsp request:request.ottReq isCache:YES];
            request.successBlock(request.ottReq, response.ottRsp);
        }
        else {
            NSInteger errorCode = (NSInteger)response.httpRsp.retCode;
            NSError *error = [[NSError alloc] initWithDomain:@"MsaHttpError" code:errorCode userInfo:nil];
            request.failureBlock(request.ottReq, error);
        }
    }];
    
    return YES;
}

- (void)cancel
{
    [self.access cancel];
}

+ (void)cancelPreviousRequests
{
    DS_DEBUG(@"SNetTask cancelPreviousRequests");
    [MsaAccess cancelPreviousRequests];
}

+ (void)resetRequestTimeoutSeconds:(NSInteger)timeout
{
    if (timeout > 0) {
        gTimeout = (unsigned int)timeout;
    }
    
}

+ (void)stopTask
{
    DS_DEBUG(@"%@ : %s", NSStringFromClass([self class]), __func__);
    gSNetTaskNormal = NO;
}

+ (void)resumeTask
{
    DS_DEBUG(@"%@ : %s", NSStringFromClass([self class]), __func__);
    gSNetTaskNormal = YES;
}

+ (void)registerRationalCheck:(RationalCheckRef)rcheck
{
    DS_DEBUG(@"%@ : %s", NSStringFromClass([self class]), __func__);
    gRationalCheck = rcheck;
}

+ (void)resetHttpHead:(NSMutableArray *)httphead
{
    DS_DEBUG(@"%@ : %s", NSStringFromClass([self class]), __func__);
    [MsaAccess setHttpHeader:httphead];
}

+ (void)resetHttpKeepAliveSeconds:(int)seconds
{
    DS_DEBUG(@"%@ : %s", NSStringFromClass([self class]), __func__);
    
}

+ (void)resetCertPath:(NSString *)certPath
{
    [MsaAccess setCertificate:certPath];
}

+ (void)registerRetryNSErrorArray:(NSArray<NSNumber *> *)errorArray
{
    gErrorArray = [NSMutableArray arrayWithArray:errorArray];
}

+ (void)disableVerifyHttpsCert
{
    gDisableVerifyHttpsCert = YES;
}

- (void)dealloc
{
    [self cancel];
    // NSLog(@"%@ dealloc", NSStringFromClass([self class]));
}

@end

