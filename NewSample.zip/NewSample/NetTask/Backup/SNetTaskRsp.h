/*!
 @file SNetTaskRsp.h
 Network response tools
 @copyright 2017 Huawei Software Technologies Co., Ltd. All rights reserved
 */

#import "MsaAccess.h"
#import "OTTHTTPProtocol.h"

/**
 * the network task response,which super class is MsaAccessResponse
 */

@interface SNetTaskRsp : MsaAccessResponse

/**
 * OTT response
 */
@property(nonatomic, strong)OTTRspRef ottRsp;


@end
