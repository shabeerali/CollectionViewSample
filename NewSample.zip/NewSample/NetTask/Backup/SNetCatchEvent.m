//
//  SNetCatchEvent.m
//  DHOTT
//
//  Copyright © 2016年 Huawei Software Technologies Co., Ltd. All rights reserved.
//

#import "SNetCatchEvent.h"

@implementation SNetCatchEvent

- (instancetype)init
{
    if (self = [super init]) {
        self.disableVerifyHttpsCert = NO;
    }
    return self;
}


- (BOOL)registerUnifiledCallBack:(id <SNetTaskUnifiedCallBackProtocol>)unifiled
{
    if ( ![unifiled conformsToProtocol:@protocol(SNetTaskUnifiedCallBackProtocol)] ) {
        return NO;
    }
    self.unified = unifiled;
    return YES;
}

@end
