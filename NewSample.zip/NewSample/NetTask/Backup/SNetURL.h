//
//  SNetURL.h
//  DHOTT
//  net url class
//  Copyright (c) 2015年 Huawei Software Technologies Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SNetURL : NSObject

/**
 time out
 */
@property (nonatomic, assign) NSInteger timeout;

/**
 is http post
 */
@property (nonatomic, assign) BOOL isHttpPost;

/**
 follow location
 */
@property (nonatomic, assign) BOOL followLocation;

/**
 disable verify cert
 */
@property (nonatomic, assign) BOOL disableVerifyCert;

/**
 init data with url

 @param aURL url
 @return NSData
 */
- (NSData *)dataWithURL:(NSString *)aURL;

/**
 string with url

 @param aURL url
 @return string
 */
- (NSString *)stringWithURL:(NSString *)aURL;

/**
 data with url

 @param aURL url
 @param body body
 @return NSData
 */
- (NSData *)dataWithURL:(NSString *)aURL reqBody:(NSString *)body;

/**
 effective url

 @return string
 */
- (NSString *)effectiveURL;

/**
 http code

 @return integer
 */
- (NSInteger)httpCode;

/**
 write file to path

 @param destPath dest path
 @param aURL url
 @return bool value
 */
- (BOOL)writeFileToPath:(NSString *)destPath fromURL:(NSString *)aURL;

/**
 write file to path

 @param destPath dest path
 @param aURL url
 @param timeout timeout
 @return bool value
 */
- (BOOL)writeFileToPath:(NSString *)destPath fromURL:(NSString *)aURL timeout:(NSInteger)timeout;

/**
 write file to path

 @param destPath dest path
 @param aURL url
 @param body request body
 @param timeout time out
 @return bool value
 */
- (BOOL)writeFileToPath:(NSString *)destPath fromURL:(NSString *)aURL reqBody:(NSString *)body timeout:(NSInteger)timeout;

@end
