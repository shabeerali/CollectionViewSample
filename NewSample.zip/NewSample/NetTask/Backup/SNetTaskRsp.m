//
//  SNetTaskRsp.m
//  OTTSDKTest
//
//  Created by OTT on 2017/11/7.
//  Copyright © 2017年 huawei. All rights reserved.
//

#import "SNetTaskRsp.h"

@implementation SNetTaskRsp

- (void)prepare
{
    if (self.httpRsp.body.length > 0) {
        [self.ottRsp unpack:self.httpRsp.body];
    }
}

@end
