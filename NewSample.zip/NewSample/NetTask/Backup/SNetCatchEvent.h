/*!
 @file SNetCatchEvent.h
 Network cache event
 @copyright 2017 Huawei Software Technologies Co., Ltd. All rights reserved
 */

#import <Foundation/Foundation.h>
#import "OTTHTTPProtocol.h"

#define SNETCEvent [SNetCatchEvent shareInstance]

typedef NS_ENUM(NSInteger, OTTExceptionCode)
{
    OTT_UNSECURY_HTTPS_CONNECTION = 2083,
    OTT_SESSION_EXPIRED_AUTOLOGIN = 2084,
    OTT_SESSION_EXPIRED_RELOGIN = 2085,
    OTT_RECEIVE_ERROR_DATA_FORMAT = 2086,
    OTT_NETWORK_DISCONNECTED = 2087,
    OTT_SYSTEM_CANCEL_REQUEST = 2088,
    OTT_NETWORK_SQM_REPORT = 2089,
    OTT_SYSTEM_LOGIN_OCCASION = 2090,
    OTT_SYSTEM_MEMORY_FAILED = 2091,
    OTT_EXCEPTION_END
};

@protocol SNetTaskUnifiedCallBackProtocol <NSObject>

/**
 * receive response successfuly
 
 @param aRsp a response
 @param aReq a request
 @param isCache caching or not
 */
- (void)successReceiveResponse:(OTTRspRef)aRsp request:(OTTReqRef)aReq isCache:(BOOL)isCache;

@end

/*!
 @class SNetTask
 @superclass NSObject
 @abstract This class is a network cache class
 
 */
@interface SNetCatchEvent : NSObject

/**
 Https certification verify disabled
 */
@property(nonatomic, assign) BOOL disableVerifyHttpsCert;

/**
 * the unified type confirmed SNetTaskUnifiedCallBackProtocol
 */
@property(nonatomic, strong) id <SNetTaskUnifiedCallBackProtocol> unified;

/**
 * instance type
 
 @return Return to its own type value
 */
+ (instancetype)shareInstance;

/**
 * register unified callback
 
 @param unifiled unifiled callback confirm SNetTaskUnifiedCallBackProtocol
 @return if SNetCache and param is nomarl return YES otherwise return NO
 */
- (BOOL)registerUnifiledCallBack:(id <SNetTaskUnifiedCallBackProtocol>)unifiled;

@end
