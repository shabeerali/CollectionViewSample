/*!
 @file SNetTaskReq.h
 Network request tools
 @copyright 2017 Huawei Software Technologies Co., Ltd. All rights reserved
 */

#import "MsaAccess.h"
#import "OTTHTTPProtocol.h"
#import "SNetTaskRsp.h"

@interface SNetTaskReq : MsaAccessRequest

/**
 OTT request
 */
@property(nonatomic, strong) OTTReqRef ottReq;

/**
 * the callback of response successfuly with the request
 */
@property (copy) void (^successBlock)(OTTReqRef, OTTRspRef);

/**
 * the callback of response failed with the errorcode duo to the request
 */

@property (copy) void (^failureBlock)(OTTReqRef, NSError *);

/**
 * when send the request ,the callback of cacel network lation
 */
@property (copy) void (^cancellationBlock)(OTTReqRef);

/**
 * init with the OTT request
 
 @param ottReq a request confirm OTTReqRef
 @return return the calss own type
 */
- (instancetype)initWithOTTReq:(OTTReqRef)ottReq;

@end
