/*!
 @file SNetTask.h
 Network base tools,VSP interface access
 @copyright 2017 Huawei Software Technologies Co., Ltd. All rights reserved
 */


#import <Foundation/Foundation.h>
#import "OTTHTTPProtocol.h"

typedef BOOL (^RationalCheckRef)(OTTReqRef aReq);

/*!
 @class SNetTask
 @superclass NSObject
 @abstract This class is a vsp interface access class, you can send a request and implement callback in block
 
 */
@interface SNetTask : NSObject
{
    /*! task queue */
    NSMutableArray *mTaskQue;
}

/*! 
 @abstract send a request and implement callback in block
 @param aReq a request confirm OTTPackageProtocol and OTTRequestProtocol 
 @param success sucess receive response from server, aReq is the sent request, aRsp is response from server
 @param failure failed receive from server. you can get detailed information from error
 @return if SNetTask and param is nomarl return YES otherwise return NO
 */
- (BOOL)send:(OTTReqRef)aReq
     success:(void (^)(OTTReqRef aReq, OTTRspRef aRsp))success
     failure:(void (^)(OTTReqRef aReq, NSError *error))failure;

/*!
 @abstract send a request and implement callback in block
 @param aReq a request confirm OTTPackageProtocol and OTTRequestProtocol
 @param success sucess receive response from server, aReq is the sent request, aRsp is response from server
 @param failure failed receive from server. you can get detailed information from error
 @param rtimes if rtimes > 0 ,and you have rigisterd retry NSError use registerRetryNSErrorArray, snettask will auto resend again until success or failure reach rtimes
 @return if SNetTask and param is nomarl return YES otherwise return NO
 */
- (BOOL)send:(OTTReqRef)aReq
     success:(void (^)(OTTReqRef aReq, OTTRspRef aRsp))success
     failure:(void (^)(OTTReqRef aReq, NSError *error))failure
  retryTimes:(NSInteger)rtimes;


/*!
 @abstract cancel all the requests on the SNetTask
 */
- (void)cancel;

@end

/*!
 @abstract This class
 
 */
@interface SNetTask (SNetExtendedGloble)

/*!
 @abstract cancel all the requests in the system
 */
+ (void)cancelPreviousRequests;

/*!
 @abstract set the http or https connect timeout seconds
 @param timeout seconds
 */
+ (void)resetRequestTimeoutSeconds:(NSInteger)timeout;

/*!
 @abstract stop the sentask, after stopTask, every request will return NO, until resumeTask
 */
+ (void)stopTask;

/*!
 @abstract resumeTask, let snettask resume normal
 */
+ (void)resumeTask;

/*!
 @abstract register rational check before send
 @param rcheck snettask will call this function to check environment before send, if return NO, send will callback in failure
 */
+ (void)registerRationalCheck:(RationalCheckRef)rcheck;

/*!
 @abstract register http/https header
 @param httphead set the http/https header
 */
+ (void)resetHttpHead:(NSMutableArray *)httphead;

/*!
 @abstract reset http keep alive seconds, if seconds ==0 tcp will close after request finish
 @param seconds http keep alive seconds
 */
+ (void)resetHttpKeepAliveSeconds:(int)seconds;

/*!
 @abstract reset https certification path
 @param certPath https certification path
 */
+ (void)resetCertPath:(NSString *)certPath;

/*!
 @abstract register retry NSError
 @param errorArray retry NSError array
 */
+ (void)registerRetryNSErrorArray:(NSArray<NSNumber *> *)errorArray;

/*!
 @abstract Https certification verified disabled
 */
+ (void)disableVerifyHttpsCert;

@end
