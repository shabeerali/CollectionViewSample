//
//  SNetURL.m
//  DHOTT
//
//  Copyright (c) 2015年 Huawei Software Technologies Co., Ltd. All rights reserved.
//

#import "SNetURL.h"
#import "MsaAccess.h"

@interface SNetURL ()
{
    
}

@property(nonatomic, strong) NSString *mEffectiveURL;

@property(nonatomic, assign) NSInteger mHttpCode;

@property(nonatomic, strong) NSData *mResponse;


@end

@implementation SNetURL

- (instancetype)init
{
    if (self = [super init]) {
        self.timeout = 20;
        self.followLocation = 1;
        self.isHttpPost = false;
    }
    return self;
}

- (void)requestWithURL:(const char *)url body:(const char *)body bodyLen:(int)bodyLen
{
    
    self.mEffectiveURL = nil;
    self.mResponse = nil;
    
    MsaHttpRequest *aReq = [[MsaHttpRequest alloc] init];
    aReq.url = [NSString stringWithFormat:@"%s", url];
    aReq.body = [[NSData alloc] initWithBytes:body length:bodyLen];
    aReq.keepalive = false;
    aReq.timeout = (unsigned int)self.timeout;
    aReq.verifyCertFlag = !(self.disableVerifyCert);
    aReq.method = (self.isHttpPost ? MSAHTTP_POST : MSAHTTP_GET);
    aReq.urlRedirection = self.followLocation;
    
    
    MsaHttpResponse *aRsp = [MsaAccess download:aReq];
    _mHttpCode = aRsp.retCode;
    _mEffectiveURL = aRsp.effectiveUrl;
    self.mResponse = aRsp.body;
}


- (NSData *)dataWithURL:(NSString *)aURL
{
    return [self dataWithURL:aURL reqBody:nil];
}

- (NSData *)dataWithURL:(NSString *)aURL reqBody:(NSString *)body
{
    if (body.length == 0) {
        [self requestWithURL:[aURL UTF8String] body:NULL bodyLen:0];
    }
    else {
        [self requestWithURL:[aURL UTF8String] body:[body UTF8String] bodyLen:(int)body.length];
    }
    return self.mResponse;
}

- (NSString *)stringWithURL:(NSString *)aURL
{
    [self dataWithURL:aURL];
    if ( self.mResponse ) {
        return [[NSString alloc] initWithData:self.mResponse encoding:NSUTF8StringEncoding];
    }
    return nil;
}


- (NSString *)effectiveURL
{
    return self.mEffectiveURL;
}

- (NSInteger)httpCode
{
    return self.mHttpCode;
}

- (BOOL)writeFileToPath:(NSString *)destPath fromURL:(NSString *)aURL
{
    return [self writeFileToPath:destPath fromURL:aURL timeout:0];
}

- (BOOL)writeFileToPath:(NSString *)destPath fromURL:(NSString *)aURL timeout:(NSInteger)timeout
{
    
    return [self writeFileToPath:destPath fromURL:aURL reqBody:nil timeout:timeout];
}

- (BOOL)writeFileToPath:(NSString *)destPath fromURL:(NSString *)aURL reqBody:(NSString *)body timeout:(NSInteger)timeout
{
    if (destPath.length==0 || aURL.length==0 || timeout<=0) {
        return NO;
    }
    
    MsaHttpDownLoadFile *download = [[MsaHttpDownLoadFile alloc] init];
    download.url = aURL;
    if ( body.length > 0 ) {
        download.body = [[NSData alloc] initWithBytes:[body UTF8String] length:[body length]];
    }
    download.filePath = destPath;
    download.timeout = (unsigned int)timeout;
    download.verifyCertFlag = !(self.disableVerifyCert);
    download.method = (self.isHttpPost ? MSAHTTP_POST : MSAHTTP_GET);
    download.urlRedirection = self.followLocation;
    
    NSInteger ret = [MsaAccess downloadFile:download process:nil];
    _mHttpCode = ret;
    return (ret == 0);
}

- (void)dealloc
{

}

@end
