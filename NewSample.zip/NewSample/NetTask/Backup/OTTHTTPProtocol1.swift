import Foundation

#if !OTTHTTPProtocol_h
//#define OTTHTTPProtocol_h

enum OTTReqLevel : Int {
    case ott_NORMAL_REQ = 0
    case ott_HIGHT_REQ = 1
    case ott_SUPER_REQ = 2
    case ott_STOP_REQ = 3
}

typealias OTTReqRef = (OTTPackageProtocol & OTTRequestProtocol)
typealias OTTRspRef = (OTTPackageProtocol & OTTResponseProtocol)
protocol OTTPackageProtocol: NSObjectProtocol {
    /**
     pack
     
     @return data
     */
    func pack() -> Data?
    /**
     unpack
     
     @param source source description
     @return return value description
     */
    func unpack(_ source: Data?) -> Any?
    /*!- (Class)ClassForNSArrayElement:(NSString *)elementName;
     
     *  In Rsp, there are NSARRY, and NSMutableArray needs a overloading method to return the type of the corresponding member
     *
     *  @param jsonName jsonName description
     *
     *  @return return value description
     */
    func classforJsonName (jsonName: String?) -> AnyClass
    /**
     valueForKey
     
     @param key key description
     @return return value description
     */
    func value(forKey key: String) -> Any?
}

protocol OTTRequestProtocol: NSObjectProtocol {
    /**
     reqURL
     
     @return return value description
     */
    func reqURL() -> String?
    /**
     rspObject
     
     @return return value description
     */
    func rspObject() -> Self
    /**
     reqLevel
     
     @return return value description
     */
    func reqLevel() -> OTTReqLevel
    /**
     httpPostMethod
     
     @return return value description
     */
    func httpPostMethod() -> Bool
    /**
     lastToSend
     
     @return return value description
     */
    func lastToSend() -> Bool
    /**
     loginOccasionDisabled
     
     @return return value description
     */
    func loginOccasionDisabled() -> Bool
    /**
     writeDownInLog
     
     @return return value description
     */
    func writeDownInLog() -> Bool
    /**
     httpShortLink
     
     @return return value description
     */
    func httpShortLink() -> Bool
    /**
     isSessionExpired
     */
    var isSessionExpired: Bool { get set }
}

protocol OTTResponseProtocol: NSObjectProtocol {
    func rspCode() -> String?
}
#endif

