//
//  SNetReq.swift
//  GoldApp
//
//  Created by Shabeerali Kudukkil on 25/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation
let VSP_NAMESPACE = "/VSP/V3/"

/*!
 *    @brief  The base class for all requests.
 */
class SNetReq: MetaAbstractClass, OTTRequestProtocol {
    func rspObject() -> Self {
        
        return self
    }
    
    // debug mode, defaul value is NO, if YES, this request will return session expired.
    var isSessionExpired = false
    var urlSuffixParameters: String?
    var extensionFields: [Any]?
    
    
    func reqURL() -> String? {
        return httpURL()
    }
    
    func httpURL() -> String {
        /*
        let reqClassName = NSStringFromClass(SNetReq.self)
        let interfaceName = (reqClassName as? NSString)?.substring(to: reqClassName.count - "Req".count)
        let url = "\(UserInfoManager.shared().vspURL)\(VSP_NAMESPACE)\(interfaceName ?? "")"
        if urlSuffixParameters.length > 0 {
            return "\(url)?\(urlSuffixParameters)"
        }
        return url
         */
         return ""
 
    }
    
    func httpsURL() -> String {
        /*
        let reqClassName = NSStringFromClass(SNetReq.self)
        let interfaceName = (reqClassName as? NSString)?.substring(to: reqClassName.count - "Req".count)
        let url = "\(VSP_HTTPSURL)\(VSP_NAMESPACE)\(interfaceName ?? "")"
        
        //    int i = rand();
        //    if (i%4 == 0) {
        //        url = [NSString stringWithFormat:@"%@%@%@", @"http://10.10.10.232:8086", VSP_NAMESPACE, interfaceName];
        //    }
        
        
        if urlSuffixParameters.length > 0 {
            return "\(url)?\(urlSuffixParameters)"
        }
        return url
 */
        return ""
    }
     /*
    func rspObject() -> Self {
       
        let reqClassName = NSStringFromClass(SNetReq.self)
        let interfaceName = (reqClassName as? NSString)?.substring(to: reqClassName.count - "Req".count)
        let respClassName = interfaceName ?? "" + ("Rsp")
        let MetaClass: AnyClass? = NSClassFromString(respClassName)
        assert(MetaClass != nil, "can't find childclass \(respClassName) , check response class name like \"xxxxRsp\"")
        
        return MetaClass()!
 
    }
  */
    
    func reqLevel() -> OTTReqLevel {
        
        return OTTReqLevel.ott_NORMAL_REQ
        
    }
    
    func lastToSend() -> Bool {
        return false
    }
    
    func httpPostMethod() -> Bool {
        return true
    }
    func loginOccasionDisabled() -> Bool {
        return false
    }
    
    func writeDownInLog() -> Bool {
        return true
    }
    
    func httpShortLink() -> Bool {
        return false
    }
    
    deinit {
    }

}
