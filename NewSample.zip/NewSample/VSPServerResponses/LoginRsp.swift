//
//  LoginRsp.swift
//  GoldApp
//
//  Created by Shabeerali Kudukkil on 17/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation
class LoginRsp : SNetRsp {
    
    /*!
     * User gateway (VSP) address，formate http://<VSPip>:<VSPhttpport>.
     If the address is IP, IP address supports V4 or V6, and the platform returns the corresponding user gateway (VSP) address according to the network address type accessed by the terminal.
     */
    var vspURL: String?
    /*!
     * The HTTPS address of the user gateway (VSP) server, when the user gateway server supports the HTTPS protocol.，formate http://<VSPip>:<VSPhttpport>.
     The IP and Port here are the IP and Port of the user gateway server.
     If the address is IP, IP address supports V4 or V6, and the platform returns the corresponding user gateway (VSP) address according to the network address type accessed by the terminal.
     
     If the client is using HTTPS interaction with the user gateway server, the HTTPS port can be obtained by this parameter.
     
     Whether the user gateway (VSP) server supports the HTTPS protocol can be configured on the IPIV platform side.
     */
    var vspHttpsURL: String?
    /*
     */
    var encryptToken: String?
    /* */    /*Encryption type, the value is as follows.：
     0001：clear
     0002：HUAWEI MD5
     0003：163MD5
     0005：AES*/
    var encryptionType: String?
    /* */    /*!
     * The root certificate is issued to the address and is returned only when the user gateway (UGW) server supports the root certificate.，formatter like http://ip or domain:port/getrootceraddrEPG/CA/iptv_ca.der。
     The IP and Port here are the IP and Port of the user gateway (UGW) server.
     If the address is IP, IP address supports V4 or V6, and the platform returns the corresponding user gateway (UGW) address according to the network address type accessed by the terminal.
     If the client needs to update the root certificate, you can obtain the root certificate download address by this parameter. If the client does not support HTTPS, ignore this parameter.
     */
    var rootCerAddr: String?
    /*!
     * Upgrade the server domain name and return after authentication.
     formatter：http://ip/ or domain:port/
     port default 80。
     IP addresses support V4 or V6, and the platform returns the corresponding server address based on the network address type accessed by the terminal.
     */
    var upgradeDomain: String?
    /*!
     * Backup the upgrade server domain name, after authentication successful return.
     formatter：http://ip/ or domain:port/，
     port default 80。
     IP addresses support V4 or V6, and the platform returns the corresponding server address based on the network address type accessed by the terminal.
     */
    var upgradeDomainBackup: String?
    /*!
     * The Domain of the terminal network, the authentication is successful and returns.
     formatter：http:// or domain:port/
     port default 80。
     IP addresses support V4 or V6, and the platform returns the corresponding server address based on the network address type accessed by the terminal.
     instructions
     When the domain name is empty, it is not connected to the terminal network.
     */
    var mgmtDomain: String?
    /*!
     * The Domain of the backup management server is returned after the authentication is successful.
     formatter：http:// or domain:port/
     port default 80。
     IP addresses support V4 or V6, and the platform returns the corresponding server address based on the network address type accessed by the terminal.
     */
    var mgmtDomainBackup: String?
    /*!
     * Domain of the NTP server. The authentication is successful and returns.
     formatter：http:// or domain:port/
     port default 80。
     IP addresses support V4 or V6, and the platform returns the corresponding server address based on the network address type accessed by the terminal.
     */
    var ntpDomain: String?
    /*!
     *   Back up the Domain of the NTP server and return after authentication.
     formatter：http:// or domain:port/
     port default 80。
     IP addresses support V4 or V6, and the platform returns the corresponding server address based on the network address type accessed by the terminal.
     */
    var ntpDomainBackup: String?
    /*!
     *  Support bandwidth management, including:
         0：NO
         1：YES
     */
    var streamMgmtEnable: String?
    /*!
     *    @brief  O
     MetaStreamType[]
     StreamType Bandwidth interval configuration items.
     */
    var streamTypes: [Any]?
    /*!
     *   For system Parameters related to the user, see the "Parameters" type.
     */
    var parameters: MetaParameters?
    /*!
     *   For terminal system parameters, see the "Configuration" type.
     */
    var terminalParm: MetaConfiguration?
    
    
    func isCache() -> Bool {
        return true
    }
    
    /**
     classForJsonName
     
     @param jsonName jsonName
     @return Class
     */
    func classforJsonName(jsonName: String?) -> AnyClass {
        if (jsonName == "streamTypes") {
            return MetaStreamType.self
        } else if (jsonName == "extensionFields") {
            return MetaNamedParameter.self
        } else if (jsonName == "parameters") {
            return MetaParameters.self
        } else if (jsonName == "terminalParm") {
            return MetaConfiguration.self
        } else {
            return NSNull.self
        }
    }
    
    /**
     useDHEncrypt
     
     @return BOOL
     */
    func useDHEncrypt() -> Bool {
        return encryptionType == "0005"
    }
}
