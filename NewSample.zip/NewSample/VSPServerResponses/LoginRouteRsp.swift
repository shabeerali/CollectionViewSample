//
//  LoginRouteRsp.swift
//  GoldApp
//
//  Created by Shabeerali Kudukkil on 16/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation
class LoginRouteRsp: SNetRsp {
    /**
     vspURL
     */
    var vspURL : String?
    /**
     backupVspURLs
     */
    var backupVspURLs: [Any] = []
    /**
     vspHttpsURL
     */
    var vspHttpsURL : String?
    /**
     backupVspHttpsURLs
     */
    var backupVspHttpsURLs: [Any] = []
    
    /**
     vspIp
     
     @return NSString
     */
    func vspIp() -> String? {
        if !(vspURL != nil) {
            return nil
        }
        let surl = URL(string: vspURL!)
        return surl?.host
    }
    
    /**
     allVspURLs
     
     @return NSArray
     */
    func allVspURLs() -> [Any]? {
        var array: [AnyHashable] = []
        if (vspURL != nil) {
            array.append(vspURL)
        }
        if backupVspURLs.count>0 {
            array.append(backupVspURLs as! AnyHashable)
        }
        return array
    }
    
    /**
     allHttpsURLs
     
     @return NSArray
     */
    func allHttpsURLs() -> [Any]? {
        var array: [AnyHashable] = []
        if (vspHttpsURL != nil) {
            array.append(vspHttpsURL)
        }
        if backupVspHttpsURLs.count>0 {
            array.append(backupVspHttpsURLs as! AnyHashable)
        }
        return array
    }
}
