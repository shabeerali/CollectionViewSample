
//
//  UserInfoManager.swift
//  GoldApp
//
//  Created by Shabeerali Kudukkil on 25/01/19.
//  Copyright © 2019 Shabeerali Kudukkil. All rights reserved.
//

import Foundation
    class UserInfoManager: NSObject {
        var vspURL : String?
        /**
         mAuthenticateReq
         */
        //@property (atomic, strong) AuthenticateReq *mAuthenticateReq;
        
        /**
         mAuthenticateRsp
         */
        //@property (atomic, strong) AuthenticateRsp *mAuthenticateRsp;
        
        /**
         login url
         */
        var loginUrl : String?
        
        /**
         instance
         
         @return instance type
         */
        static let sharedManagerInstance: UserInfoManager? = {
            var instance = UserInfoManager()
            return instance
        }()
        
        class func shared() -> UserInfoManager {
            // `dispatch_once()` call was converted to a static variable initializer
            return sharedManagerInstance!
        }
    }

